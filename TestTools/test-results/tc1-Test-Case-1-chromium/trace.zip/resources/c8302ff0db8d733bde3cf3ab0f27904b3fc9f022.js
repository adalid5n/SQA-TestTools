
/* Start file "modules/window-sizes" */
var tlSize = {
    current: [],
    dimensions: [],

    init: function(){
        tlSize.dimensions = entryData.layoutSizes;
        $(window).on('layoutChange', tlSize.bodyClass);
        tlSize.resize();
        $(window).on('resize', tlSize.resize);
    },

    resize: function(){
        $.each(tlSize.dimensions, function(key, val){
            var from = val[0]*1;
            var to = val[1];
            if (to) {
                to = to*1
            } else {
                to = 10000
            }
            var data = { };
            var w = window.innerWidth;
            if (!w) {
                w = $(window).width();
            }
            if (from <= w && w <= to) {
                if ($.inArray(key, tlSize.current ) === -1) {
                    tlSize.current.push(key);
                    tlSize.current = tlSize.sort(tlSize.current);
                    data = {
                        key: key,
                        status: 'in',
                        from: from,
                        to: to,
                        current: tlSize.current
                    };
                    $(window).trigger('layoutChange', [data]);
                    $(window).trigger(key+'in', [data]);
                }
            } else {
                var index = tlSize.current.indexOf(key);
                if (index > -1) {
                    tlSize.current.splice(index, 1);
                    tlSize.current = tlSize.sort(tlSize.current);
                    data = {
                        key: key,
                        status: 'out',
                        from: from,
                        to: to,
                        current: tlSize.current
                    };
                    $(window).trigger('layoutChange', [data]);
                    $(window).trigger(key+'out', [data]);
                }
            }
        })
    },

    sort: function(arr){
        var v = [];
        var t = [];
        var tmp = [];
        var l = arr.length;
        for (var i = 0; i < l; i++) {
            tmp[i] = '0w0';
            $.each(arr, function (key, val) {
                v = val.split('w');
                v[0] = v[0]*1;
                v[1] = v[1]*1;
                if (!v[1]) {
                    v[1] = 10000
                }
                t = tmp[i].split('w');
                t[0] = t[0]*1;
                t[1] = t[1]*1;
                if (t[1] < v[1]) {
                    tmp[i] = val
                } else if (t[1] == v[1] && t[0] > v[0]) {
                    tmp[i] = val
                }
            });
            var index = arr.indexOf(tmp[i]);
            arr.splice(index, 1);
        }

        return tmp
    },

    bodyClass: function(e, d){
        if (d.status == 'in') {
            $('body').addClass(d.key)
        }
        if (d.status == 'out') {
            $('body').removeClass(d.key)
        }
    }

};
/* End file "modules/window-sizes" */


/* Start file "modules/tl-init" */
if (!Object.assign) {
    Object.defineProperty(Object, 'assign', {
        enumerable: false,
        configurable: true,
        writable: true,
        value: function(target, firstSource) {
            'use strict';
            if (target === undefined || target === null) {
                throw new TypeError('Cannot convert first argument to object');
            }

            var to = Object(target);
            for (var i = 1; i < arguments.length; i++) {
                var nextSource = arguments[i];
                if (nextSource === undefined || nextSource === null) {
                    continue;
                }

                var keysArray = Object.keys(Object(nextSource));
                for (var nextIndex = 0, len = keysArray.length; nextIndex < len; nextIndex++) {
                    var nextKey = keysArray[nextIndex];
                    var desc = Object.getOwnPropertyDescriptor(nextSource, nextKey);
                    if (desc !== undefined && desc.enumerable) {
                        to[nextKey] = nextSource[nextKey];
                    }
                }
            }
            return to;
        }
    });
}

tl.reducers = {};
function tl_action(script) {
    if (typeof jQuery == 'function') {
        tl_start = true;
        var action = function (block) {
            var key = true;
            $.each(block.js, function (j, js) {
                var include_index = tl_include_js.indexOf(js);
                if (include_index == -1 || tl_include_loaded.indexOf(js) == -1) {
                    key = false;
                }
            });
            if (key && block && typeof block.script === "function") {
                if (typeof requestIdleCallback === "function"){
                    requestIdleCallback(block.script);
                } else {
                    block.script()
                }
            }
            return key
        };
        $.each(script, function (i, block) {
            if (!action(block)) {
                $.each(block.js, function (j, js) {
                    var include_index = tl_include_js.indexOf(js);
                    if (include_index == -1) {
                        tl_include_js.push(js);
                        include_index = tl_include_js.indexOf(js);
                        $.ajax({
                            url: js, success: function () {
                                tl_include_loaded.push(js);
                                $(window).trigger('tl_action_' + include_index);
                            },
                            error: function (a, b, c) {
                                console.error('Error: "' + js + '" ' + c);
                            },
                            dataType: 'script',
                            cache: true
                        });
                    }
                    $(window).on('tl_action_' + include_index, function () {
                        action(block)
                    })
                })
            }
        })
    } else {
        setTimeout(function () {
            tl_action(script)
        }, 100)
    }
    document.cookie = "xwidth="+window.outerWidth;
    document.cookie = "xheight="+window.outerHeight;
};

tl(createJsUrl('main.js'), function(){
    $('.footerTitle, .gift-code .heading-4').off('click').click(function(){
        if($(window).width() >= 720) return;
        $(this).toggleClass('active');
        $('~ *', this).slideToggle();
    });
});

/* End file "modules/tl-init" */


/* Start file "reducers/account" */
tl.reducers.account = function(state, actions){
    if (!state) state = entryData.account;
    if (!state) state = [];

    var newState ='';

    switch (actions.type) {
        case 'LOGGED_IN':
            newState = JSON.parse(JSON.stringify(state));

            newState = actions.value.account;

            return newState;
        default:
            return state
    }
}
/* End file "reducers/account" */


/* Start file "reducers/themeSettings" */
tl.reducers.themeSettings = function(state, actions){
    if (!state) state = entryData.themeSettings;
    if (!state) state = [];

    var newState ='';

    switch (actions.type) {
        case 'CHANGE_THEME_SETTING':
            newState = JSON.parse(JSON.stringify(state));

            newState = actions.value.account;

            return newState;
        default:
            return state
    }
}
/* End file "reducers/themeSettings" */

